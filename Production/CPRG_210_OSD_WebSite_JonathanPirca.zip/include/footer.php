<?php
//**************************************
//**                                  **
//** Author: Jonathan Pirca           **
//** Created: Nov 11, 2018            **
//** Module: HTML / CSS / JS / PHP    **
//** Assignment: Individual Project 1 **
//**                                  **
//************************************** 
?>
<div class="footer">
  <p>Copyright &copy; 2008 Coconut Travel Agency Inc. All rights reserved</p>
</div>